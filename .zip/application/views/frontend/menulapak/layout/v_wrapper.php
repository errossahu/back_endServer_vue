<?php
$this->proteksi->proteksi_halaman();
require_once('v_head.php'); 
require_once('v_nav.php');
require_once('v_content.php'); 
require_once('v_footer.php'); 

?>