<?php

require_once('v_headCuci.php');
require_once('v_headHome.php');
require_once('v_header.php');
require_once('v_nav.php');
require_once('v_content.php');
require_once('v_footerCuci.php');   
?>